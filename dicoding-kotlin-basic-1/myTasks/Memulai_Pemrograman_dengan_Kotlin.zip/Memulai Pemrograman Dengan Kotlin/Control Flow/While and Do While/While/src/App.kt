// main function
fun main() {
    var counter = 8

    while (counter <= 7){
        println("Hello, World!")
        counter++
    }
}